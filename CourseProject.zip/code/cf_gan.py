import tensorflow as tf
from dis_model import DIS
from gen_model import GEN
import pickle
import os
import numpy as np
import multiprocessing
from  time import strftime ,localtime
from sklearn.metrics import log_loss,roc_auc_score
cores = multiprocessing.cpu_count()

#########################################################################################
# Hyper-parameters
#########################################################################################
BUDGET = 0.02  #$$$
ITEM_PER_USER = 100#$$$
EMB_DIM = 5
USER_NUM = 943
ITEM_NUM = 1683
BATCH_SIZE = 16
INIT_DELTA = 0.05
FAKE_USER_NUM = int(BUDGET*USER_NUM) #$$$
TOTAL_USER_NUM = USER_NUM + FAKE_USER_NUM #$$$
EPOCHES=10
TEST_D_EPOCHES=120
D_EPOCHES=120
G_EPOCHES=50
GENERATOR_SAMPLES=500

all_items = set(range(ITEM_NUM))
fake_users=np.arange(USER_NUM,TOTAL_USER_NUM)#$$$
workdir = 'ml-100k/'
time_stamp = strftime('%Y_%m_%d_%H_%M_%S', localtime())
logdir="tfsummary/"+time_stamp
DIS_TRAIN_FILE = workdir + 'dis-train.txt'

#########################################################################################
# Load data
#########################################################################################
user_pos_train = {}
with open(workdir + 'movielens-100k-train.txt')as fin:
    for line in fin:
        line = line.split()
        uid = int(line[0])
        iid = int(line[1])
        r = float(line[2])
        if r > 3.99:
            if uid in user_pos_train:
                user_pos_train[uid].append(iid)
            else:
                user_pos_train[uid] = [iid]

user_pos_test = {}
with open(workdir + 'movielens-100k-test.txt')as fin:
    for line in fin:
        line = line.split()
        uid = int(line[0])
        iid = int(line[1])
        r = float(line[2])
        if r > 3.99:
            if uid in user_pos_test:
                user_pos_test[uid].append(iid)
            else:
                user_pos_test[uid] = [iid]

#all_users = user_pos_train.keys()
#all_users.sort()

input_users = []
input_items = []
input_labels = []
test_input_users = []
test_input_items = []
test_input_labels = []

def generate_real_data():
    for u in user_pos_train:
        for i in user_pos_train[u]:
            input_users.append(u)
            input_items.append(i)
            input_labels.append(1)
        all_neg_items=[]
        for i in all_items:
            if i  not in user_pos_train[u]:
                all_neg_items.append(i)
        neg_items=np.random.choice(all_neg_items,len(user_pos_train[u]))
        for i in neg_items:
            input_users.append(u)
            input_items.append(i)
            input_labels.append(0)

def generate_test_data():
    for u in user_pos_test:
        for i in user_pos_test[u]:
            test_input_users.append(u)
            test_input_items.append(i)
            test_input_labels.append(1)
        all_neg_items=[]
        for i in all_items:
            if i  not in user_pos_test[u]:
                all_neg_items.append(i)
        neg_items=np.random.choice(all_neg_items,len(user_pos_test[u]))
        for i in neg_items:
            test_input_users.append(u)
            test_input_items.append(i)
            test_input_labels.append(0)

def test_generator_performance(sess,discriminator):
    index = 0
    test_size=len(test_input_users)
    all_preds=[]
    while True:
        if index >= test_size:
            break
        if index + BATCH_SIZE - 1 < test_size:
            input_user, input_item = test_input_users[index:index + BATCH_SIZE], test_input_items[index:index + BATCH_SIZE],

        else:
            input_user, input_item = test_input_users[index:test_size], test_input_items[index:test_size]

        index += BATCH_SIZE
        preds= sess.run(discriminator.preds,feed_dict={discriminator.u: input_user, discriminator.i: input_item})
        all_preds.extend(preds)
    log = log_loss(test_input_labels, all_preds)
    auc = roc_auc_score(test_input_labels, all_preds)

    return log,auc



def dcg_at_k(r, k):
    r = np.asfarray(r)[:k]
    return np.sum(r / np.log2(np.arange(2, r.size + 2)))


def ndcg_at_k(r, k):
    dcg_max = dcg_at_k(sorted(r, reverse=True), k)
    if not dcg_max:
        return 0.
    return dcg_at_k(r, k) / dcg_max


def simple_test_one_user(x):
    rating = x[0]
    u = x[1]

    test_items = list(all_items - set(user_pos_train[u]))
    item_score = []
    for i in test_items:
        item_score.append((i, rating[i]))

    item_score = sorted(item_score, key=lambda x: x[1])
    item_score.reverse()
    item_sort = [x[0] for x in item_score]

    r = []
    for i in item_sort:
        if i in user_pos_test[u]:
            r.append(1)
        else:
            r.append(0)

    p_3 = np.mean(r[:3])
    p_5 = np.mean(r[:5])
    p_10 = np.mean(r[:10])
    ndcg_3 = ndcg_at_k(r, 3)
    ndcg_5 = ndcg_at_k(r, 5)
    ndcg_10 = ndcg_at_k(r, 10)

    return np.array([p_3, p_5, p_10, ndcg_3, ndcg_5, ndcg_10])


#$$$
def generate_fake_data(sess, model):
    input_fake_users=[]
    input_fake_items=[]
    input_fake_labels=[]
    for u in fake_users:
        assert (u-USER_NUM>=0)
        rating = sess.run(model.all_logits, {model.u: u-USER_NUM})#only FAKE_USER-NUM user_embeddings in generator
        rating = np.array(rating) / 1  # Temperature
        exp_rating = np.exp(rating)
        prob = exp_rating / np.sum(exp_rating)
        fake_samples = np.random.choice(np.arange(ITEM_NUM), replace=False,size=ITEM_PER_USER, p=prob)
        for i in fake_samples:
            input_fake_users.append(u)
            input_fake_items.append(i)
            input_fake_labels.append(1)
    return input_fake_users,input_fake_items,input_fake_labels





def main():
    print ("load model...")
    generator = GEN(ITEM_NUM, FAKE_USER_NUM, EMB_DIM, lamda=0.0 / BATCH_SIZE, param=None, initdelta=INIT_DELTA,
                    learning_rate=0.001)
    discriminator = DIS(ITEM_NUM, TOTAL_USER_NUM, EMB_DIM, lamda=0.1 / BATCH_SIZE, param=None, initdelta=INIT_DELTA,
                        learning_rate=0.001)
    discriminator_t = DIS(ITEM_NUM, TOTAL_USER_NUM, EMB_DIM, lamda=0.1 / BATCH_SIZE, param=None, initdelta=INIT_DELTA,
                        learning_rate=0.001)

    #config = tf.ConfigProto()
    #config.gpu_options.allow_growth = True
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = "1"
    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

    #print "gen ", simple_test(sess, generator)
    #print "dis ", simple_test(sess, discriminator)

    #dis_log = open(workdir + 'dis_log.txt', 'w')
    #gen_log = open(workdir + 'gen_log.txt', 'w')


    #real data
    generate_real_data()
    generate_test_data()
    # origninal training--------------------------------------------------------------
    writer = tf.summary.FileWriter(logdir+"/origin", sess.graph)
    for d_epoch in range(TEST_D_EPOCHES):
        train_size = len(input_users)
        index = 0
        training_loss_sum = 0
        while True:
            if index >= train_size:
                break
            if index + BATCH_SIZE - 1 < train_size:
                input_user, input_item, input_label = input_users[index:index + BATCH_SIZE], input_items[
                                                                                                   index:index + BATCH_SIZE], input_labels[
                                                                                                                              index:index + BATCH_SIZE]
            else:
                input_user, input_item, input_label = input_users[index:train_size], input_items[
                                                                                           index:train_size], input_labels[
                                                                                                              index:train_size]
            index += BATCH_SIZE

            training_loss, _ = sess.run([discriminator_t.pre_loss, discriminator_t.d_updates],
                                        feed_dict={discriminator_t.u: input_user, discriminator_t.i: input_item,
                                                   discriminator_t.label: input_label})

            training_loss_sum += training_loss

        print("original training, d_epoch: {0}, average_training_loss: {1}".format(d_epoch,training_loss_sum / train_size))
        if d_epoch % 5 == 0 or d_epoch == TEST_D_EPOCHES - 1:
            test_log_loss,test_auc = test_generator_performance(sess, discriminator_t)
            print("original training, d_epoch: {0}, test_log_loss: {1}, test_auc: {2}".format(d_epoch, test_log_loss,test_auc))

            summary = tf.Summary(value=[tf.Summary.Value(tag='auc', simple_value=test_auc),
                                        tf.Summary.Value(tag='log_loss', simple_value=test_log_loss),
                                        tf.Summary.Value(tag='train_loss',simple_value=training_loss_sum / train_size)])
            writer.add_summary(summary, d_epoch)

    # test discriminator with random fake data ----------------------------------------------------------
    writer = tf.summary.FileWriter(logdir + "/random", sess.graph)
    sess.run(tf.variables_initializer([discriminator_t.user_embeddings, discriminator_t.item_embeddings, discriminator_t.item_bias]))
    input_fake_users, input_fake_items, input_fake_labels = generate_fake_data(sess, generator)
    mixed_input_users = input_users + input_fake_users
    mixed_input_items = input_items + input_fake_items
    mixed_input_labels = input_labels + input_fake_labels
    train_size = len(mixed_input_users)
    for d_epoch in range(TEST_D_EPOCHES):
        index = 0
        training_loss_sum = 0
        while True:
            if index >= train_size:
                break
            if index + BATCH_SIZE - 1 < train_size:
                input_user, input_item, input_label = mixed_input_users[
                                                      index:index + BATCH_SIZE], mixed_input_items[
                                                                                 index:index + BATCH_SIZE], mixed_input_labels[
                                                                                                            index:index + BATCH_SIZE]
            else:
                input_user, input_item, input_label = mixed_input_users[index:train_size], mixed_input_items[
                                                                                           index:train_size], mixed_input_labels[
                                                                                                              index:train_size]
            index += BATCH_SIZE

            training_loss, _ = sess.run([discriminator_t.pre_loss, discriminator_t.d_updates],
                                        feed_dict={discriminator_t.u: input_user, discriminator_t.i: input_item,
                                                   discriminator_t.label: input_label})

            training_loss_sum += training_loss

        print("epoch: random, d_epoch: {0}, average_training_loss: {1}".format( d_epoch,
                                                                            training_loss_sum / train_size))
        if d_epoch % 5 == 0 or d_epoch == TEST_D_EPOCHES - 1:
            test_log_loss, test_auc = test_generator_performance(sess, discriminator_t)
            print("epoch: random, d_epoch: {0}, test_log_loss: {1}, test_auc: {2}".format(d_epoch, test_log_loss,
                                                                                     test_auc))
            summary = tf.Summary(value=[tf.Summary.Value(tag='auc', simple_value=test_auc),
                                        tf.Summary.Value(tag='log_loss',simple_value=test_log_loss),
                                        tf.Summary.Value(tag='train_loss',simple_value=training_loss_sum / train_size)])
            writer.add_summary(summary, d_epoch)


    # minimax training-----------------------------------------------
    for epoch in range(EPOCHES):
        # fit fake data according to its prob
        for d_epoch in range(D_EPOCHES):
            # generate new data every 5 epoches
            if d_epoch % 5== 0:
                input_fake_users, input_fake_items, input_fake_labels=generate_fake_data(sess, generator)
                mixed_input_users = input_users + input_fake_users
                mixed_input_items = input_items + input_fake_items
                mixed_input_labels=input_labels + input_fake_labels
                train_size=len(mixed_input_users)
            index = 0
            training_loss_sum=0
            while True:
                if index >= train_size:
                    break
                if index + BATCH_SIZE -1< train_size :
                    input_user, input_item, input_label=mixed_input_users[index:index+BATCH_SIZE],mixed_input_items[index:index+BATCH_SIZE],mixed_input_labels[index:index+BATCH_SIZE]
                else:
                    input_user, input_item, input_label=mixed_input_users[index:train_size],mixed_input_items[index:train_size],mixed_input_labels[index:train_size]
                index += BATCH_SIZE

                training_loss,_ = sess.run([discriminator.pre_loss,discriminator.d_updates],
                             feed_dict={discriminator.u: input_user, discriminator.i: input_item,
                                        discriminator.label: input_label})

                training_loss_sum+=training_loss

            print ("discriminator,epoch: {0}, d_epoch: {1}, average_training_loss: {2}".format(epoch,d_epoch,training_loss_sum/train_size))




        # Train G


        for g_epoch in range(G_EPOCHES):  # 50
            # for u in fake_users:
            for u in fake_users:
                #sample_lambda = 0.2
                #pos = user_pos_train[u]
                rating = sess.run(generator.all_logits, {generator.u: u-USER_NUM})# only FAKE_USER_NUM user_embeddings in generator
                exp_rating = np.exp(rating)
                prob = exp_rating / np.sum(exp_rating)  # prob is generator distribution p_\theta
                #pn = (1 - sample_lambda) * prob
                #pn[pos] += sample_lambda * 1.0 / len(pos)
                # Now, pn is the Pn in importance sampling, prob is generator distribution p_\theta
                sample = np.random.choice(np.arange(ITEM_NUM), GENERATOR_SAMPLES, p=prob,replace=False)
                ###########################################################################
                # Get reward and adapt it with importance sampling       $$$one user/all fake users ??$$$
                ###########################################################################

                reward = sess.run(discriminator.reward, {discriminator.u: u, discriminator.i: sample})

                #reward = reward * prob[sample] / prob[sample]
                ###########################################################################
                # Update G
                ###########################################################################
                _ = sess.run(generator.gan_updates,
                             {generator.u: u-USER_NUM, generator.i: sample, generator.reward: reward})# only FAKE_USER_NUM user_embeddings in generator

                if (g_epoch == G_EPOCHES - 1):
                    print(epoch, u)
                    print(reward)

        # test generator------------------------------------------------
        writer = tf.summary.FileWriter(logdir + "/epoch{0}".format(epoch), sess.graph)
        sess.run(tf.variables_initializer(
            [discriminator_t.user_embeddings, discriminator_t.item_embeddings, discriminator_t.item_bias]))
        input_fake_users, input_fake_items, input_fake_labels = generate_fake_data(sess, generator)
        mixed_input_users = input_users + input_fake_users
        mixed_input_items = input_items + input_fake_items
        mixed_input_labels = input_labels + input_fake_labels
        train_size = len(mixed_input_users)
        for d_epoch in range(TEST_D_EPOCHES):
            index = 0
            training_loss_sum = 0
            while True:
                if index >= train_size:
                    break
                if index + BATCH_SIZE - 1 < train_size:
                    input_user, input_item, input_label = mixed_input_users[
                                                          index:index + BATCH_SIZE], mixed_input_items[
                                                                                     index:index + BATCH_SIZE], mixed_input_labels[
                                                                                                                index:index + BATCH_SIZE]
                else:
                    input_user, input_item, input_label = mixed_input_users[
                                                          index:train_size], mixed_input_items[
                                                                             index:train_size], mixed_input_labels[
                                                                                                index:train_size]
                index += BATCH_SIZE

                training_loss, _ = sess.run([discriminator_t.pre_loss, discriminator_t.d_updates],
                                            feed_dict={discriminator_t.u: input_user, discriminator_t.i: input_item,
                                                       discriminator_t.label: input_label})

                training_loss_sum += training_loss

            print("epoch: {0}, d_epoch: {1}, average_training_loss: {2}".format(epoch, d_epoch,
                                                                                training_loss_sum / train_size))
            if d_epoch % 5 == 0 or d_epoch == TEST_D_EPOCHES - 1:
                test_log_loss, test_auc = test_generator_performance(sess, discriminator_t)
                print("epoch{3}, d_epoch: {0}, test_log_loss: {1}, test_auc: {2}".format(d_epoch, test_log_loss,
                                                                                         test_auc, epoch))
                summary = tf.Summary(value=[tf.Summary.Value(tag='auc', simple_value=test_auc),
                                            tf.Summary.Value(tag='log_los',simple_value=test_log_loss),
                                            tf.Summary.Value(tag='train_loss', simple_value=training_loss_sum / train_size)])
                writer.add_summary(summary, d_epoch)


    #gen_log.close()
    #dis_log.close()
    generator.save_model(sess,"generator_param")
    discriminator.save_model(sess,"discriminator_param")

if __name__ == '__main__':
    main()

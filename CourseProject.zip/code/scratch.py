import tensorflow as tf
a=tf.constant([
    [1,2],
])
b=tf.constant([
    [1,2],
    [3,4],
    [5,6],
    [7,8],
    [9,10]
])
c=a+b
input_data=tf.placeholder(tf.int32)

with tf.Session() as sess:
    re,pl=sess.run([c,input_data],{input_data:1})
    print(pl)
    print(pl.shape)

print(re)
print(re[0])
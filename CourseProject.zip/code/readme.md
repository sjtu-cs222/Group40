Example code for item recommendation attack. To run the experiments for irgan:
```
python cf_gan.py
```